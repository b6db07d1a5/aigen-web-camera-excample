# Mobile (and Desktop) Camera App Template (HTML, CSS, JS and WebRTC)

- https://webrtc.github.io/samples/
- https://www.webrtc-experiment.com/
- https://www.html5rocks.com/en/tutorials/getusermedia/intro/
- https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
